const express = require('express');
const Event = require('../models/eventModel');
const { verifyToken } = require('../middleware/authMiddleware');
const router = express.Router();

// CREATE Event (Protected)
router.post('/', verifyToken, async (req, res) => {
  try {
    const { title, description, date } = req.body;
    const newEvent = new Event({
      title,
      description,
      date,
      createdBy: req.user.id
    });
    await newEvent.save();
    res.status(201).json({ message: 'Event created successfully ✅', event: newEvent });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// READ All Events (Public)
router.get('/', async (req, res) => {
  const events = await Event.find().populate('createdBy', 'name email');
  res.status(200).json(events);
});

// UPDATE Event (Protected)
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found ❌' });

    if (event.createdBy.toString() !== req.user.id)
      return res.status(403).json({ message: 'Not authorized to update this event 🔒' });

    const updated = await Event.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).json({ message: 'Event updated successfully ✏️', updated });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE Event (Protected)
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found ❌' });

    if (event.createdBy.toString() !== req.user.id)
      return res.status(403).json({ message: 'Not authorized to delete this event 🔒' });

    await Event.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Event deleted successfully 🗑️' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
